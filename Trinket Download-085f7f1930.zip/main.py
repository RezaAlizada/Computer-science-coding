# Exam grade program

# -------------------------
# Subprograms
# -------------------------
def interest(x, y, z):
  m = True
  x=x/100
  i=1
  while m == True:
    y = x*y+y
    print("After", i, "years of compound interest your balance is ", y)
    i=i+1
    if y >= z:
      m = False
    else:
      m = True
# -------------------------
# Main program
# -------------------------
aer = float(input("Enter interest rate in %: "))
money = float(input("Enter your balance: "))
targetmoney = float(input("Enter your target balance: "))
x = interest(aer, money, targetmoney)
# Cashpoint program

# -------------------------
# Subprograms
# -------------------------
def dispense(amount):
  amount = str(amount)
  print("W",amount)
  y = True
  while y == True:
    amount = int(amount)
    while amount>=20:
      print("W20")
      amount = amount-20
    while amount>=10:
      print("W10")
      amount = amount-10
    while amount>=5:
      print("W5")
      amount = amount-5
# -------------------------
# Main program
# -------------------------
w = int(input("Enter the amount of money to withdraw only in fives: "))
x = dispense(w)
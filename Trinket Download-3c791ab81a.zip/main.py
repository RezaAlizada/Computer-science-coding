# Valid month program

# -------------------------
# Subprograms
# -------------------------
def validate_month():
  x = True
  while x == True:
    month = int(input("Enter a month: "))
    if month>0 and month<13:
      x = False
  return
# -------------------------
# Main program
# -------------------------

x = validate_month()
print("Thank you. Input accepted.")

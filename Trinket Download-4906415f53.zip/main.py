# Measurements program

# -------------------------
# Subprograms
# -------------------------
def fi(x):
  print(x*12, "inches")
def inf(x):
  print(x/12, "feet")
# -------------------------
# Main program
# -------------------------
m = True
while m == True:
  x= input("1. Feet to inches 2. Inches to feet 3. Quit")
  if x == "1":
    b = float(input("Enter amount of feet"))
    a = fi(b)
  elif x == "2":
    c = float(input("Enter amount of inches"))
    d = inf(c)
  elif x == "3":
    m = False
  else:
    print("Try again")
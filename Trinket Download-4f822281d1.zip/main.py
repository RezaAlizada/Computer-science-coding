# Square root program

# -------------------------
# Subprograms
# -------------------------
def sqroot(x):
  root = x
  y = False
  while y == False:
    root = 0.5*(root+(x/root))
    w = root*2
    if root % 2 ==0:
      y = True
    print(root)
  return(root)
# -------------------------
# Main program
# -------------------------
num = float(input("Enter a number you want to find the square root of:"))
print("The square root of", num, "is", sqroot(num))
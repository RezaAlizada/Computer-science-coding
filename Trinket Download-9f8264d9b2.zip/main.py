# Periodic table program

# -------------------------
# Subprograms
# -------------------------
def P(x):
  if x == Lithium:
    print("Symbol: Li")
    print("Name: Lithium")
    print("Atomic weight: 6.94")
    print("Group: Alkali Metals")
  elif x == Sodium:
    print("Symbol: Na")
    print("Name: Sodium")
    print("Atomic weight: 22.9")
    print("Group: Alkali Metals")
  elif x == Potassium:
    print("Symbol: K")
    print("Name: Potassium")
    print("Atomic weight: 39.098")
    print("Group: Alkali Metals")
  elif x == Fluorine:
    print("Symbol: F")
    print("Name: Fluorine")
    print("Atomic weight: 18.998")
    print("Group: Halogens")
  elif x == Chlorine:
    print("Symbol: Cl")
    print("Name: Chlorine")
    print("Atomic weight: 35.45")
    print("Group: Halogens")
  elif x == Bromine:
    print("Symbol: Br")
    print("Name: Bromine")
    print("Atomic weight: 79.904")
    print("Group: Halogens")
  else:
    print("Try again")
# -------------------------
# Main program
# -------------------------
x = str(input("Enter element name:"))
P(x)
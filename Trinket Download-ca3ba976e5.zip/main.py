# PIN program

# -------------------------
# Subprograms
# -------------------------
def get_pin():
  y = True
  z = 0
  while y == True:
    z = z+1
    PIN = int(input("Please enter your pin:"))
    if PIN == 7528:
      y = False
    else:
      print("Try again")
      if z == 3:
        y = False
      else:
        y = True
  if PIN == 7528:
    x = 1
  else:
    x = 2
  if x == 1:
    print("Security check passed")
  else:
    print("Locked out")
# -------------------------
# Main program
# -------------------------
x = get_pin()

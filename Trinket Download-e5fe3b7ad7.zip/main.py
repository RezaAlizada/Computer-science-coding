# Circle properties program

# -------------------------
# Subprograms
# -------------------------
def circle_area(r):
  y=r*r*3.14
  return(y)
def radius(di):
  x= di/2
  return(x)
# -------------------------
# Main program
# -------------------------
di = int(input("Enter the diameter of the circle"))
r = radius(di)
c = circle_area(r)
print("The area of the circle is", c)
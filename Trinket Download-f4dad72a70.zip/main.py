# Microscopy program

# -------------------------
# Subprograms
# -------------------------
def magnification(actual_size, image_size):
  x= (actual_size*10000)/image_size
  return(x)
# -------------------------
# Main program
# -------------------------
actual_size = float(input("Enter size in micrometers: "))
image_size = float(input("Enter image size in cm: "))
mag = magnification(actual_size, image_size)
print("The magnification is", mag ,"X")